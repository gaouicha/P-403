function NavCtrl($scope){
	$scope.menu='home';
}